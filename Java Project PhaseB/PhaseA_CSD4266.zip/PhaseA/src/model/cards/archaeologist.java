package model.cards;

/**
 * Create an Archaeologist Card
 * @version 1.0
 * @author Aleksandar - Mladenovic
 */
public class archaeologist extends card {

	/**
	 * User can take two more tile from any Area except from the one he took earlier in his turn.
     * <b>Transformer:</b> Users the card abillity and set used to true.
     * <b>Postcondition:</b> The card abillity has been activated and the card is used now.
     */
	public void useCard() {}
}
