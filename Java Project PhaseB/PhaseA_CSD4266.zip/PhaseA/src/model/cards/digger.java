package model.cards;

/**
 * Create a Digger Card
 * @version 1.0
 * @author Aleksandar - Mladenovic
 */
public class digger extends card {
	
	/**
	 * User can take two more tile from the Areas except he took earlier in his turn
     * <b>Transformer:</b> Users the card abillity and set used to true.
     * <b>Postcondition:</b> The card abillity has been activated and the card is used now.
     */
	public void useCard() {}
}
