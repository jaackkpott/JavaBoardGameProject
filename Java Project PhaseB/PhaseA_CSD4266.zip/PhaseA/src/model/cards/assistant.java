package model.cards;

/**
 * Create an Assistant Card
 * @version 1.0
 * @author Aleksandar - Mladenovic
 */
public class assistant extends card {
	
	/**
	 * User can take one more tile from any Area
     * <b>Transformer:</b> Users the card abillity and set used to true.
     * <b>Postcondition:</b> The card abillity has been activated and the card is used now.
     */
	public void useCard() {}
}
