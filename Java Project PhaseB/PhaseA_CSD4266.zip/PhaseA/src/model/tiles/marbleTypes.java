package model.tiles;

/**
 * This enum contains the types of Marble that we can find.
 * @version 1.0
 * @author Aleksandar - Mladenovic
 */
public enum marbleTypes {
	Caryatids,
	Sphinxes;
}
