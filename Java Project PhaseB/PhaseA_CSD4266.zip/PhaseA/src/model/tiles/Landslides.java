package model.tiles;

/**
 * Create a landslibes that will cover the entrance
 * @version 1.0
 * @author Aleksandar - Mladenovic
 */
public class Landslides implements tile{
	
}
