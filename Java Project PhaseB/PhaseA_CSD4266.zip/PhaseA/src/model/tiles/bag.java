package model.tiles;

import java.util.ArrayList;


/**
 * This class creates a new Bag with a Collection of tiles.
 * @version 1.0
 * @author Aleksandar - Mladenovic
 */
public class bag {
	private ArrayList<tile> tiles;
	
	/**Constructor.
     * 
     * <b>Postcondition</b>Creates a new Bag with a new tiles ArrayList.
     *
     */
    public bag(){
    	this.tiles = new ArrayList<tile>();
    	this.init_tiles();
    }
    
    /**
     * <b>Transformer:</b> Initializes the 135 tiles.
     * <b>Postcondition:</b> The tiles have been initialised in the bag and ready to get pulled.
     */
    private void init_tiles(){}
    
    /**
     * <b>Observer:</b> Returns true if this list is empty.
     * <b>Postcondition:</b> Returns true if this list contains no elements.
     * @return true if this list contains no elements
     */
    public boolean isEmpty(){return false;}
    
    /**
     * <b>Transformer:</b> Adds a tile to the list.
     * <b>Postcondition:</b> A tile has been added to the list.
     * @param i
     */
    public void addTile(tile i){  }
    
    /**
     * <b>Transformer:</b> Removes a tile from the end of the list.
     * <b>Postcondition:</b> A tile has been removed from the of end of the list.
     * @return the last tile of the bag
     */
    public void removeTile(){}
	
    /**
     * <b>Accessor:</b> Returns the size of a list.
     * <Postcondition:</b> The size of the list has been returned.
     * @return size of the list
     */
    public int size(){return tiles.size();}
	
    /**
     * <b>Transformer:</b> Clears an ArrayList 
     * <b>Postcondition:</b> An ArrayList is cleared.
     */
     public void clearAll(){}
     
     /**
      * <b>Accessor:</b> returns the 4 tiles in the end
      * <b>Postcondition:</b> the 4 tile in the end has been returned
      * @return the 4 tiles in the end has been returned
      * */
     public ArrayList<tile> return4Tiles() { return tiles;}
     
     /**
      * <b>Transformer:</b> Remove 4 tiles from the end of the bag 
      * <b>Postcondition:</b> 4 tiles from the bag have been removed.
      */
      public void remove4Tiles(){}
      
      /**
       * <b>Transformer:</b> Randomizes the tiles in the bag
       * <b>Postcondition:</b> The content in the bag have been randomized
       */
      public void randomizeBag() {}
}
